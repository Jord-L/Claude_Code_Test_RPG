# modules/

This directory contains a lot of deprecated C code. This should be
moved/refactored to better C++ abstractions.
