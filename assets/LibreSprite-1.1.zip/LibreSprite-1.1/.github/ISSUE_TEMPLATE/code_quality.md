---
name: Code quality
about: Have you seen bad code? Click here
title: ''
labels: code quality
assignees: ''

---
##### What's wrong with the code?
<!-- A clear and concise description of the poor quality you've noticed -->

##### How should it be improved?
<!-- A clear and concise description of what you think is a better approach -->

##### Additional context  
<!-- Add any other context about the issue here -->
